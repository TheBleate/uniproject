  <?php
/* +------------------------------------+
   |       FITXER DE CONFIGURACIÓ       |
   +------------------------------------+ */

   //ACCESS A LA BASE DE DADES
   define('DB_USER', 'Andrei');
   define('DB_PASS', '1234');
   define('DB_NAME', 'Proiectus');
   define('DB_ADDRESS','192.168.224.101');
   define('DB_PORT', '3306');

   //MODE DEPURACIÓ
   //define('DEBUG_MODE' true)
?>
